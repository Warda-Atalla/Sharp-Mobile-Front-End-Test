import React from 'react';
import ReactDOM from 'react-dom';
import Button from 'muicss/lib/react/button';

class Example extends React.Component {
  render() {
    return (
      <div>
        <div>
          <Button variant="raised">button</Button>
          <Button variant="raised" color="primary">button</Button>
          <Button variant="raised" color="danger">button</Button>
          <Button variant="raised" color="accent">button</Button>
        </div>
    
      
      </div>
    );
  }
}

ReactDOM.render(<Example />, document.getElementById('example'));
angular.module('demo', [])
.controller('Hello', function($scope, $http) {
    $http.get('http://rest-service.guides.spring.io/greeting').
        then(function(response) {
            $scope.greeting = response.data;
        });
});
  <script> import React from 'react';
   import ReactDOM from 'react-dom';
   import Button from 'muicss'/'lib'/'react'/'button');
  }

class Example extends React.Component {
  render() {
    return (
   
    );
  }
}</script>}}